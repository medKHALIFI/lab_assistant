
R:\seFramework\ClientToolkit_Direct_SDK_Wpf\Resources

R:\seSDK\SDK\Samples\Applications\Silverlight\Lite\Lite\Resources\Localization


