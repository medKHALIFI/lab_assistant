﻿using System;

using SpatialEye.Framework.Client;

namespace Lite
{
  /// <summary>
  /// The application names and resource paths
  /// </summary>
  public partial class ViewModelLocator
  {
    /// <summary>
    /// The ViewModelLocator additional setup for viewModels
    /// </summary>
    private void SetupAdditionalViewModels()
    {
    }
  }
}
