﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The main page
  /// </summary>
  public partial class LitePrintA4Template1MainPageView : UserControl
  {
    /// <summary>
    /// The default constructor
    /// </summary>
    public LitePrintA4Template1MainPageView()
    {
      InitializeComponent();
    }
  }
}
