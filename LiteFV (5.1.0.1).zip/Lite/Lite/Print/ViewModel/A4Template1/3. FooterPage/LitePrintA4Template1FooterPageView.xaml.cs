﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The Footer page
  /// </summary>
  public partial class LitePrintA4Template1FooterPageView : UserControl
  {
    /// <summary>
    /// The default constructor
    /// </summary>
    public LitePrintA4Template1FooterPageView()
    {
      InitializeComponent();
    }
  }
}
