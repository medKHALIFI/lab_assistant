﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The header page
  /// </summary>
  public partial class LitePrintA4Template2HeaderPageView : UserControl
  {
    /// <summary>
    /// Default constructor
    /// </summary>
    public LitePrintA4Template2HeaderPageView()
    {
      InitializeComponent();
    }
  }
}
