﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The Footer page
  /// </summary>
  public partial class LitePrintA4Template2FooterPageView : UserControl
  {
    /// <summary>
    /// The default constructor
    /// </summary>
    public LitePrintA4Template2FooterPageView()
    {
      InitializeComponent();
    }
  }
}
