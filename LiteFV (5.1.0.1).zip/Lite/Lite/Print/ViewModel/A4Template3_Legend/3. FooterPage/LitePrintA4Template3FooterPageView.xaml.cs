﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The Footer page
  /// </summary>
  public partial class LitePrintA4Template3FooterPageView : UserControl
  {
    /// <summary>
    /// The default constructor
    /// </summary>
    public LitePrintA4Template3FooterPageView()
    {
      InitializeComponent();
    }
  }
}
