﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The main page
  /// </summary>
  public partial class LitePrintA4Template3MainPageView : UserControl
  {
    /// <summary>
    /// The default constructor
    /// </summary>
    public LitePrintA4Template3MainPageView()
    {
      InitializeComponent();
    }
  }
}
