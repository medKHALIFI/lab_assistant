﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The header page
  /// </summary>
  public partial class LitePrintA4Template3HeaderPageView : UserControl
  {
    /// <summary>
    /// Default constructor
    /// </summary>
    public LitePrintA4Template3HeaderPageView()
    {
      InitializeComponent();
    }
  }
}
