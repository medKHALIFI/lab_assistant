﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.ServiceModel;
using SpatialEye.Framework.Client;
using Lite.Resources.Localization;

namespace Lite
{
  /// <summary>
  /// The view for displaying feature details; needs to be bound to a LiteFeatureDetailsViewModel,
  /// </summary>
    public partial class LiteFactibilidadView : UserControl
  {
    /// <summary>
    /// Constructs the view for displaying feature details
    /// </summary>
    public LiteFactibilidadView()
    {
      InitializeComponent();
      cboTipo.Items.Add("RESIDENCIAL");
      cboTipo.Items.Add("EMPRESARIAL");
      cboTipo.SelectedValue="RESIDENCIAL";
      Indicador.Visibility = Visibility.Collapsed;
    }

    private void btnCalcularFactibilidad_Click(object sender, RoutedEventArgs e)
    {
        
        //limpiar();
        Indicador.InProgress = true;
        Indicador.Visibility = Visibility.Visible;
        ServiceFactibilidad.WsCalculaFactibilidadPortTypeClient proxy = new ServiceFactibilidad.WsCalculaFactibilidadPortTypeClient();
        ServiceFactibilidad.wsCalculaFactibilidadRQType peticionType = new ServiceFactibilidad.wsCalculaFactibilidadRQType();
        try
        {
            ServiceFactibilidad.calculaFactibilidadRequest peticion = new ServiceFactibilidad.calculaFactibilidadRequest();
            peticion.wsCalculaFactibilidadRQ = peticionType;
            peticionType.latitud = txtLatitud.Text.ToString();
            peticionType.longitud = txtLongitud.Text.ToString();
            peticionType.tipo_cliente = cboTipo.SelectedValue.ToString();
            proxy.calculaFactibilidadCompleted += new EventHandler<ServiceFactibilidad.calculaFactibilidadCompletedEventArgs>(calcula_factibilidad_completado);
            proxy.calculaFactibilidadAsync(peticion);
        }
        catch (CommunicationException ex)
        {
            MessageBox.Show(ex.Message);
            //lblErrores.Text=ex.Message;
            Indicador.InProgress = false;
            Indicador.Visibility = Visibility.Collapsed;
        }
    }



    void calcula_factibilidad_completado(object sender, ServiceFactibilidad.calculaFactibilidadCompletedEventArgs e)
    {
        if (e.Result==null)
        {
            MessageBox.Show("Error de Conectividad con el Servidor");
            //lblErrores.Text = "Error de Conectividad con el Servidor"; 
        }
        else {
            txtResultados.Text =  "Código de Factibilidad: " + e.Result.wsCalculaFactibilidadRS.factibilidad + Environment.NewLine;
            txtResultados.Text += "Factbilidad:            " + e.Result.wsCalculaFactibilidadRS.criterios + Environment.NewLine;
            txtResultados.Text += "Dirección:              " + e.Result.wsCalculaFactibilidadRS.direccion + Environment.NewLine;
            txtResultados.Text += "Region:                 " + e.Result.wsCalculaFactibilidadRS.region + Environment.NewLine;
            txtResultados.Text += "Ciudad:                 " + e.Result.wsCalculaFactibilidadRS.ciudad + Environment.NewLine;
            txtResultados.Text += "Zona:                   " + e.Result.wsCalculaFactibilidadRS.zona + Environment.NewLine;
            txtResultados.Text += "Distrito:               " + e.Result.wsCalculaFactibilidadRS.distrito + Environment.NewLine;
            txtResultados.Text += "Cobertura:              " + e.Result.wsCalculaFactibilidadRS.cobertura + Environment.NewLine;
            txtResultados.Text += "Comentarios:            " + e.Result.wsCalculaFactibilidadRS.comentarios + Environment.NewLine;

            
            //lblErrores.Text 
            string msg = e.Result.wsCalculaFactibilidadRS.Detalle_Respuesta.CodigoError +
                                 e.Result.wsCalculaFactibilidadRS.Detalle_Respuesta.DescripcionError +
                                 e.Result.wsCalculaFactibilidadRS.Detalle_Respuesta.MensajeError;
            MessageBox.Show(msg);

            }
        Indicador.InProgress = false;
        Indicador.Visibility = Visibility.Collapsed;
        
    }

    private void cmdLimpiar_Click(object sender, RoutedEventArgs e)
    {
        limpiar();
        
    }

    void limpiar()
    {
        txtLatitud.Text = "";
        txtLongitud.Text = "";
        txtResultados.Text = "";
        lblErrores.Text = "";
    }
    

  }
}
