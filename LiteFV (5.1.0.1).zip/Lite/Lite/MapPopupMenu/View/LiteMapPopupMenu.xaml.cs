﻿using System.Windows.Controls;

namespace Lite
{
  /// <summary>
  /// The Map's popup menu
  /// </summary>
  public partial class LiteMapPopupMenu : UserControl
  {
    /// <summary>
    /// Default constructor
    /// </summary>
    public LiteMapPopupMenu()
    {
      InitializeComponent();
    }
  }
}
